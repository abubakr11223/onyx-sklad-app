// R1 — Rol-tizimi: SOF ruxsat-dvigateli (TZ §3 «Роли и права»).
// DB importlari YO'Q, next importlari YO'Q — bu modul faqat toza lookup:
// rol + «закупку видит ли» bayrog'idan Capabilities matritsasini quradi.
// inventory.ts / photos.ts uslubida: eksport tiplar + sof funksiyalar,
// side-effektsiz (new Date() ham yo'q), alohida unit-testlanadi.
//
// MUHIM: bu R1 faqat DVIGATEL. Hech qanday majburlash / UI yashirish YO'Q —
// u R2–R4 da capabilitiesFor() natijasini o'qib qo'llaydi. Shu tufayli R1
// additiv va regresiyasiz.

/**
 * Rolning lokal string-union nusxasi. Prisma'ning `Role` enum'ini ATAYLAB
 * import qilmaymiz — shunda modul DB'siz qoladi va izolyatsiyada testlanadi.
 * A'zolari Prisma `Role` enum a'zolari bilan birebir mos (structural).
 */
export type Role =
  | "OWNER"
  | "MANAGER"
  | "WAREHOUSE"
  | "WAREHOUSE_LEAD"
  | "PARTNER";

/**
 * Складской персонал: обычный складчик И зав. складом.
 *
 * ⚠️ ИСПОЛЬЗУЙТЕ ЭТО, а не `role === "WAREHOUSE"`. Зав. складом — это складчик
 * со всеми его функциями плюс право на количество. Любая прямая сверка с
 * «WAREHOUSE» ТИХО отбирает у него склад: фото-задания, отгрузки, шоу-рум,
 * приёмку. Ошибка не падает и не видна в тестах — просто человек перестаёт
 * получать задания.
 */
export function isWarehouseRole(role: string): boolean {
  return role === "WAREHOUSE" || role === "WAREHOUSE_LEAD";
}

/**
 * Bir foydalanuvchining «nima qila oladi / nima ko'ra oladi» to'plami (TZ §3).
 * Har maydon — bitta huquq. R2+ da UI va action'lar shu bayroqlarni o'qiydi.
 */
export interface Capabilities {
  /** Sotuv/baza narxini ko'rish (basePrice). TZ §3: OWNER/MANAGER — ha. */
  canSeePrices: boolean;
  /** Закупка/маржа narxini ko'rish (purchasePrice). OWNER — DOIM; MANAGER — ruxsatga qarab. */
  canSeePurchasePrice: boolean;
  /** Sotuvni rasmiylashtirish (prodazha). TZ §3: OWNER/MANAGER. */
  canSell: boolean;
  /** Bron qo'yish (bron). TZ §3: OWNER/MANAGER. */
  canReserve: boolean;
  /** Fotozapros yuborish (CREATE) va so'rovni «Готово» yopish. TZ §3/§5.3: OWNER/MANAGER. */
  canRequestPhoto: boolean;
  /**
   * Foto-vazifalar ro'yxatini ko'rish (READ). TZ §3 sklad «задачи на фото»,
   * §7 «виден складчику», §5.9 dual site+TG. CREATE bilan aralashmasin:
   * canRequestPhoto WAREHOUSE ga BERILMAYDI (menejer so'raydi; sklad bajaradi).
   * OWNER/MANAGER/WAREHOUSE — true; PARTNER — false.
   */
  canViewPhotoTasks: boolean;
  /** Ombor amallari: приёмка/разбить/перемещение/съёмка. TZ §3: OWNER/WAREHOUSE. */
  canManageWarehouse: boolean;
  /** Aniq qoldiqlarni ko'rish (точные остатки). TZ §3: PARTNER'dan boshqa hammasi. */
  canSeeExactRemainder: boolean;
  /** Barcha bronlarni ko'rish (nafaqat o'ziniki). TZ §3: faqat OWNER. */
  canSeeAllReservations: boolean;
  /** So'rovlari menejerga yo'naltiriladimi (PARTNER oqimi). TZ §3: faqat PARTNER. */
  requestsRouteToManager: boolean;
  /**
   * Harakatlar tarixini (AuditLog: кто/что/когда) ko'rish. TZ §8 + §3 —
   * Владелец «видит … действия сотрудников». FAQAT OWNER; менеджеру журнал
   * всех действий (чужие продажи/клиенты) не даём. Свой скоуп — кандидат в v2.
   */
  canSeeHistory: boolean;
  /**
   * Akkauntlarni boshqarish (OWN-03): xodim akkauntlarini yaratish/o'chirish
   * (soft), rol va parolni o'zgartirish. FAQAT OWNER — root/egasi. Menejer ham,
   * boshqalar ham akkaunt yarata olmaydi (ruxsatlarni oshirib yuborish xavfi).
   */
  canManageAccounts: boolean;
  /**
   * Заявки дизайнера/партнёра (A1, TZ §6.8) — очередь лидов /zayavki. Их
   * обрабатывает менеджер («заявка принята, менеджер свяжется»), поэтому видят
   * OWNER/MANAGER. WAREHOUSE — нет (не продаёт). PARTNER — нет (он их СОЗДАЁТ,
   * но чужих не видит).
   */
  canSeeLeads: boolean;
  /**
   * Раздел «Должники» (TZ №9 §5) — активные/погашенные долги, погашение.
   * FAQAT OWNER (как «Сотрудники» / canManageAccounts). Менеджер долги оформляет
   * при продаже, но список и погашение — только владелец.
   */
  canSeeDebts: boolean;
  /**
   * Справочники «Клиенты» / «Объекты» (TZ №10+11 §7, §12).
   * OWNER и MANAGER — true (работают с клиентами при продаже и в разделах).
   * WAREHOUSE/PARTNER — false.
   */
  canSeeClients: boolean;
  /**
   * Видеть ВСЕХ клиентов/объектов, не только своих (TZ №10+11 §12).
   * OWNER — true; MANAGER — false (только managerId = actor).
   * Аналог canSeeAllReservations.
   */
  canSeeAllClients: boolean;
  /**
   * TZ №15 — раздел «Отгрузки»: OPEN list + archive.
   * OWNER / MANAGER / WAREHOUSE. Scope (all vs own) is enforced in listShipments.
   */
  canSeeShipments: boolean;
  /**
   * TZ №15 — confirm physical hand-over. OWNER + WAREHOUSE (canManageWarehouse).
   * Manager does not self-confirm by default (design D4).
   */
  canConfirmShipment: boolean;
  /**
   * TZ №15 Slice 3 — раздел «Шоу-рум» (list + send + return).
   * PLACEHOLDER (design D5/D6): OWNER + MANAGER + WAREHOUSE.
   * Owner may later restrict warehouse or manager — change only this matrix.
   */
  canSeeShowroom: boolean;
  /** Send unit to showroom (same roles as canSeeShowroom for now). */
  canSendToShowroom: boolean;
  /**
   * Менять КОЛИЧЕСТВО партии (плиты / м² / счётчики узоров) при редактировании.
   * Согласовано 2026-08-12: владелец + зав. складом. Обычный складчик правит
   * размеры, дату, поставщика, узоры и локации, но не количество — оно влияет
   * на остаток, брони, долги и продажи.
   *
   * Раньше это право вычислялось как `caps.canSeeHistory` («значит владелец») —
   * обходной признак, который с появлением зав. складом сразу стал неверным:
   * ему нужно количество, но не нужен журнал действий всех сотрудников.
   */
  canEditBatchQuantity: boolean;
  /**
   * ТЗ №17 §6 — редактирование карты склада (блоки/ориентиры). Складчик
   * выбирает локацию из готового справочника, а заводит блоки владелец или
   * зав. складом: иначе справочник снова начнёт расти из приёмки.
   */
  canEditWarehouseMap: boolean;
}

/**
 * Ruxsat matritsasi (TZ §3) — sof lookup, side-effektsiz.
 *
 * Согласовано 2026-08-12: WAREHOUSE_LEAD («Зав. складом») = WAREHOUSE во всём,
 * плюс `canEditBatchQuantity`. Отдельного столбца нет намеренно — как только он
 * появится, две колонки начнут расходиться при правках.
 *
 * | huquq                    | OWNER | MANAGER          | WAREHOUSE(+LEAD) | PARTNER |
 * |--------------------------|-------|------------------|-----------|---------|
 * | canSeePrices             | true  | true             | false     | false   |
 * | canSeePurchasePrice      | true* | = opts           | false     | false   |
 * | canSell                  | true  | true             | false     | false   |
 * | canReserve               | true  | true             | false     | false   |
 * | canRequestPhoto          | true  | true             | false     | false   |
 * | canViewPhotoTasks        | true  | true             | true      | false   |
 * | canManageWarehouse       | true  | false            | true      | false   |
 * | canSeeExactRemainder     | true  | true             | true      | false   |
 * | canSeeAllReservations    | true  | false            | false     | false   |
 * | requestsRouteToManager   | false | false            | false     | true    |
 * | canSeeHistory            | true  | false            | false     | false   |
 * | canManageAccounts        | true  | false            | false     | false   |
 * | canSeeLeads              | true  | true             | false     | false   |
 * | canSeeDebts              | true  | false            | false     | false   |
 * | canSeeClients            | true  | true             | false     | false   |
 * | canSeeAllClients         | true  | false            | false     | false   |
 * | canEditBatchQuantity     | true  | false            | LEAD only | false   |
 * | canEditWarehouseMap      | true  | false            | LEAD only | false   |
 *
 * (*) OWNER.canSeePurchasePrice — `opts` dan QAT'IY NAZAR har doim true
 * (schema: User.canSeePurchasePrice OWNER uchun e'tiborga olinmaydi).
 * MANAGER'niki — aynan `opts.canSeePurchasePrice`. WAREHOUSE/PARTNER — doim false.
 */
/**
 * Deny-by-default to'plami: BARCHA huquqlar false. Union'dan tashqari rol
 * (kelajakdagi 5-chi Role a'zosi yoki noto'g'ri cast) uchun xavfsiz javob —
 * hech qachon undefined qaytmaydi va hech qachon ortiqcha ruxsat bermaydi.
 * Hardcoded (PARTNER'ga bog'liq emas) — PARTNER kelajakda o'zgarsa ham xavfsiz.
 */
export const DENY_ALL: Capabilities = {
  canSeePrices: false,
  canSeePurchasePrice: false,
  canSell: false,
  canReserve: false,
  canRequestPhoto: false,
  canViewPhotoTasks: false,
  canManageWarehouse: false,
  canSeeExactRemainder: false,
  canSeeAllReservations: false,
  requestsRouteToManager: false,
  canSeeHistory: false,
  canManageAccounts: false,
  canSeeLeads: false,
  canSeeDebts: false,
  canSeeClients: false,
  canSeeAllClients: false,
  canSeeShipments: false,
  canConfirmShipment: false,
  canSeeShowroom: false,
  canSendToShowroom: false,
  canEditBatchQuantity: false,
  canEditWarehouseMap: false,
};

export function capabilitiesFor(
  role: Role,
  opts: { canSeePurchasePrice: boolean },
): Capabilities {
  switch (role) {
    case "OWNER":
      return {
        canSeePrices: true,
        canSeePurchasePrice: true, // OWNER — doim (opts e'tiborga olinmaydi)
        canSell: true,
        canReserve: true,
        canRequestPhoto: true,
        canViewPhotoTasks: true,
        canManageWarehouse: true,
        canSeeExactRemainder: true,
        canSeeAllReservations: true,
        requestsRouteToManager: false,
        canSeeHistory: true,
        canManageAccounts: true, // OWN-03: только Владелец управляет аккаунтами
        canSeeLeads: true, // A1: владелец видит заявки партнёров
        canSeeDebts: true, // TZ №9: «Должники» — только владелец
        canSeeClients: true, // TZ №10+11: справочники клиентов/объектов
        canSeeAllClients: true, // владелец видит всех
        canSeeShipments: true,
        canConfirmShipment: true,
        canSeeShowroom: true,
        canSendToShowroom: true,
        canEditBatchQuantity: true, // владелец — всегда
        canEditWarehouseMap: true, // ТЗ №17 §6
      };
    case "MANAGER":
      return {
        canSeePrices: true,
        canSeePurchasePrice: opts.canSeePurchasePrice, // ruxsatga qarab
        canSell: true,
        canReserve: true,
        canRequestPhoto: true,
        canViewPhotoTasks: true,
        canManageWarehouse: false,
        canSeeExactRemainder: true,
        canSeeAllReservations: false,
        requestsRouteToManager: false,
        // §3: «действия сотрудников» видит только Владелец; менеджеру журнал
        // всех действий не даём (чужие продажи/клиенты). Свой скоуп — кандидат в v2.
        canSeeHistory: false,
        canManageAccounts: false,
        canSeeLeads: true, // A1: менеджер обрабатывает заявки партнёров
        canSeeDebts: false, // TZ №9 §5: раздел только OWNER
        canSeeClients: true, // TZ №10+11: свои клиенты/объекты
        canSeeAllClients: false, // только managerId = actor
        canSeeShipments: true, // own sales' shipments
        canConfirmShipment: false, // design D4 — warehouse/owner confirm
        canSeeShowroom: true,
        canSendToShowroom: true,
        canEditBatchQuantity: false, // менеджер не трогает складской учёт
        canEditWarehouseMap: false,
      };
    case "WAREHOUSE":
    case "WAREHOUSE_LEAD":
      // Согласовано 2026-08-12: зав. складом — ЭТО складчик, со всеми его
      // функциями, плюс право на количество. Поэтому одна ветка на две роли:
      // отдельный блок неизбежно разошёлся бы при следующей правке, и зав.
      // складом молча потерял бы фото-задания или подтверждение отгрузки.
      return {
        canSeePrices: false,
        canSeePurchasePrice: false,
        canSell: false,
        canReserve: false,
        canRequestPhoto: false, // CREATE/close — menejer; bajarish — TG (§5.3)
        canViewPhotoTasks: true, // §3/§7/§5.9: vazifalar saytda ko'rinsin
        canManageWarehouse: true,
        canSeeExactRemainder: true,
        canSeeAllReservations: false,
        requestsRouteToManager: false,
        canSeeHistory: false,
        canManageAccounts: false,
        canSeeLeads: false, // склад не работает с заявками партнёров
        canSeeDebts: false,
        canSeeClients: false,
        canSeeAllClients: false,
        canSeeShipments: true,
        canConfirmShipment: true,
        canSeeShowroom: true,
        canSendToShowroom: true,
        // Единственное отличие двух складских ролей.
        canEditBatchQuantity: role === "WAREHOUSE_LEAD",
        // ТЗ №17 §6 — карту размечает зав. складом, обычный складчик — нет.
        canEditWarehouseMap: role === "WAREHOUSE_LEAD",
      };
    case "PARTNER":
      return {
        canSeePrices: false,
        canSeePurchasePrice: false,
        canSell: false,
        canReserve: false,
        canRequestPhoto: false,
        canViewPhotoTasks: false,
        canManageWarehouse: false,
        canSeeExactRemainder: false,
        canSeeAllReservations: false,
        requestsRouteToManager: true,
        canSeeHistory: false,
        canManageAccounts: false,
        canSeeLeads: false, // партнёр СОЗДАЁТ заявки, но чужих не видит
        canSeeDebts: false,
        canSeeClients: false,
        canSeeAllClients: false,
        canSeeShipments: false,
        canConfirmShipment: false,
        canSeeShowroom: false,
        canSendToShowroom: false,
        canEditBatchQuantity: false,
        canEditWarehouseMap: false,
      };
    default:
      // Union'dan tashqari qiymat (kelajakdagi 5-chi rol / noto'g'ri cast) —
      // deny-by-default: undefined qaytmaydi, ortiqcha ruxsat berilmaydi.
      return DENY_ALL;
  }
}
