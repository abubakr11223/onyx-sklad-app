// §5.5b — «Бой по фото» (TZ §5.5): server component. Bot yuborgan havoladagi
// `d` draft'ini (AI polygon + Telegram file_id) QATTIQ dekodlaydi, chertyojni
// raqamlangan tomonlar bilan ko'rsatadi va skladchidan har tomonning REAL
// o'lchamini so'raydi. Saqlash — ./actions.submitSingan (registerDirectPiece).
// Web-UI tili — RUSCHA (faqat bot o'zbekcha).
// C-pilot: разметка переведена на бренд-дизайн-систему (Button/Field/Card/Alert).
// Поведение, имена полей, валидация и поток данных НЕ менялись.

import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/lib/db";
import { getCapabilities } from "@/lib/session";
import { formatTashkentDate } from "@/lib/datetime";
import NoAccess from "@/components/NoAccess";
import { decodeShapeDraft } from "@/lib/singan";
import { renderChertyoj } from "@/lib/chertyoj";
import { submitSingan } from "./actions";
import Button, { buttonClass } from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Field, { inputClass } from "@/components/ui/Field";
import Alert from "@/components/ui/Alert";

export const metadata: Metadata = {
  title: "Бой по фото — Onyx",
};

// Partiya ro'yxati joriy DB holatini aks ettirsin.
export const dynamic = "force-dynamic";

const m2Fmt = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 1 });

function first(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}

/** Единая шапка страницы: gold-deep надзаголовок + serif-заголовок. */
function PageHeader({ subtitle }: { subtitle?: string }) {
  return (
    <header className="mb-6">
      <p className="text-xs font-semibold uppercase tracking-[0.28em] text-gold-deep">
        Onyx · склад
      </p>
      <h1 className="mt-2 font-serif text-display font-bold tracking-tight text-ink">
        Бой по фото
      </h1>
      {subtitle && <p className="mt-2 text-base text-ink/60">{subtitle}</p>}
    </header>
  );
}

export default async function SinganPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  // R2 — rol gate: бой записывает склад (canManageWarehouse: OWNER/WAREHOUSE).
  const caps = await getCapabilities();
  if (!caps.canManageWarehouse) {
    return (
      <main className="mx-auto max-w-xl p-4 pb-12">
        <NoAccess />
      </main>
    );
  }

  const sp = await searchParams;
  const ok = first(sp.ok) === "1";
  const stoneId = first(sp.stone);
  const err = first(sp.err);

  // ── Muvaffaqiyat holati: forma o'rniga yakuniy panel ──
  if (ok) {
    return (
      <main className="mx-auto max-w-xl p-4 pb-12">
        <PageHeader />
        <Alert variant="success" title="Кусок записан">
          <p className="text-ink/70">Чертёж и фото сохранены в карточке камня.</p>
          {stoneId && (
            <Link
              href={`/kamen/${stoneId}`}
              className={buttonClass("primary", "md", "mt-3")}
            >
              Открыть карточку камня
            </Link>
          )}
        </Alert>
      </main>
    );
  }

  // ── Draft: foydalanuvchi nazoratidagi URL ma'lumoti — QATTIQ dekodlash ──
  const draft = decodeShapeDraft(first(sp.d));
  if (!draft) {
    return (
      <main className="mx-auto max-w-xl p-4 pb-12">
        <PageHeader />
        <Alert variant="warning" title="Ссылка не открылась">
          <p className="text-ink/70">
            Ссылка повреждена или устарела. Отправьте фото со словом «singan» в
            бот ещё раз — или введите бой вручную.
          </p>
          <Link href="/razbit" className={buttonClass("primary", "md", "mt-3")}>
            Ввести вручную (/razbit)
          </Link>
        </Alert>
      </main>
    );
  }

  // AI-chertyoj: tomonlar 1..N raqamlangan. SVG'ni BIZ validatsiyadan o'tgan
  // polygon'dan renderChertyoj bilan yasadik (yozuvlar escapeXml qilinadi) —
  // shuning uchun dangerouslySetInnerHTML bu yerda xavfsiz.
  const svg = renderChertyoj(draft.vertices);
  const sideNumbers = draft.vertices.map((_, i) => i + 1);

  const batchRows = await db.batch.findMany({
    orderBy: [{ stoneType: { name: "asc" } }, { arrivedAt: "desc" }],
    select: {
      id: true,
      arrivedAt: true,
      slabsTotal: true,
      areaTotalM2: true,
      stoneType: { select: { name: true } },
    },
  });

  return (
    <main className="mx-auto max-w-xl p-4 pb-12">
      <PageHeader subtitle="AI распознал форму куска. Измерьте каждую сторону рулеткой и введите размеры в мм — номера сторон совпадают с чертежом." />

      {err && (
        <Alert variant="danger" className="mb-6">
          {err}
        </Alert>
      )}

      <div className="mb-6 flex justify-center rounded-card border border-ink/10 bg-paper-2/60 p-4">
        {/* SVG — bizning renderChertyoj mahsuloti (validatsiya + ekranlash).
            Ko'rsatish usuli O'ZGARMADI: inline-SVG dangerouslySetInnerHTML orqali. */}
        <div dangerouslySetInnerHTML={{ __html: svg }} />
      </div>

      <form action={submitSingan} className="flex flex-col gap-6">
        <input type="hidden" name="d" value={first(sp.d) ?? ""} />

        {/* ── Стороны ── */}
        <Card>
          <h2 className="mb-3 text-lg font-semibold text-ink">
            Стороны, мм ({draft.vertices.length})
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {sideNumbers.map((n) => (
              <Field
                key={n}
                id={`side_${n}`}
                name={`side_${n}`}
                inputMode="numeric"
                label={`Сторона ${n}`}
                placeholder="напр. 1180"
                required
              />
            ))}
          </div>
        </Card>

        {/* ── Габариты и площадь ── */}
        <Card>
          <h2 className="mb-3 text-lg font-semibold text-ink">Габариты и площадь</h2>
          <div className="grid grid-cols-2 gap-3">
            <Field
              id="boundingLengthMm"
              name="boundingLengthMm"
              inputMode="numeric"
              label="Длина, мм"
              required
            />
            <Field
              id="boundingWidthMm"
              name="boundingWidthMm"
              inputMode="numeric"
              label="Ширина, мм"
              required
            />
            <Field
              id="thicknessMm"
              name="thicknessMm"
              inputMode="numeric"
              label="Толщина, мм"
              placeholder="необязательно"
            />
            <Field
              id="areaM2"
              name="areaM2"
              inputMode="decimal"
              label="Площадь, м²"
              placeholder="необязательно"
            />
          </div>
        </Card>

        {/* ── Партия и место ── */}
        <Card>
          <h2 className="mb-3 text-lg font-semibold text-ink">Партия и место</h2>
          <div className="flex flex-col gap-4">
            <Field id="kind" label="Тип">
              <select
                id="kind"
                name="kind"
                defaultValue="BROKEN"
                className={inputClass}
              >
                <option value="BROKEN">Бой</option>
                <option value="OFFCUT">Остаток</option>
              </select>
            </Field>
            <Field id="batchId" label="Партия (камень)">
              <select id="batchId" name="batchId" required className={inputClass}>
                <option value="">— выберите партию —</option>
                {batchRows.map((b) => {
                  const qty = [
                    b.slabsTotal !== null && `${b.slabsTotal} плит`,
                    b.areaTotalM2 !== null &&
                      `${m2Fmt.format(Number(b.areaTotalM2))} м²`,
                  ]
                    .filter(Boolean)
                    .join(" / ");
                  return (
                    <option key={b.id} value={b.id}>
                      {b.stoneType.name} — {formatTashkentDate(b.arrivedAt)}
                      {qty && ` (${qty})`}
                    </option>
                  );
                })}
              </select>
            </Field>
            <label className="flex items-center gap-2 text-base text-ink/80">
              <input type="checkbox" name="decrementSlabs" value="1" />
              Бой был целой плитой партии (−1 плита)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <Field
                id="block"
                name="block"
                label="Блок"
                placeholder="напр. А"
                required
              />
              <Field
                id="landmark"
                name="landmark"
                label="Ориентир"
                placeholder="напр. 2"
                required
              />
            </div>
          </div>
        </Card>

        {/* Липкая нижняя панель отправки — CTA под большим пальцем на мобиле;
            на десктопе (md:) возвращается в обычный поток. Реальный submit
            серверного экшена (без JS) сохраняется. */}
        <div
          className="sticky bottom-0 z-10 -mx-4 border-t border-ink/10 bg-paper/90 px-4 py-3 backdrop-blur
                     md:static md:mx-0 md:border-0 md:bg-transparent md:px-0 md:py-0 md:backdrop-blur-none"
        >
          <Button type="submit" className="min-h-14 w-full text-lg font-bold">
            Сохранить
          </Button>
        </div>
      </form>
    </main>
  );
}
